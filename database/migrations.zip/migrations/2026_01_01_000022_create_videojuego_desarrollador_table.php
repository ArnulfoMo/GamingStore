<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('videojuego_desarrollador', function (Blueprint $table) {
            $table->foreignId('videojuego_id')->constrained('videojuegos');
            $table->foreignId('desarrollador_id')->constrained('desarrolladores');
                        
            $table->primary(['videojuego_id','desarrollador_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('videojuego_desarrollador');
    }
};
