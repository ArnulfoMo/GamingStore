<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('videojuego_plataforma', function (Blueprint $table) {
            $table->foreignId('videojuego_id')->constrained('videojuegos');
            $table->foreignId('plataforma_id')->constrained('plataformas');
                        
            $table->primary(['videojuegos_id','plataforma_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('videojuego_plataforma');
    }
};
